import 'package:flutter/material.dart';

void main() => runApp(const BMarketApp());

const teal = Color(0xFF008F89);
const deepTeal = Color(0xFF006B68);
const orange = Color(0xFFFF9418);
const ink = Color(0xFF183A3A);
const pale = Color(0xFFF5F7F7);

class BMarketApp extends StatelessWidget {
  const BMarketApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'B MARKET',
      theme: ThemeData(
        useMaterial3: true,
        scaffoldBackgroundColor: pale,
        colorScheme: ColorScheme.fromSeed(seedColor: teal, primary: teal, secondary: orange),
        fontFamily: 'Arial',
      ),
      home: const Directionality(textDirection: TextDirection.rtl, child: HomeScreen()),
    );
  }
}

class Product {
  final String name, store, price, unit, emoji;
  final int discount;
  const Product(this.name, this.store, this.price, this.unit, this.emoji, {this.discount = 0});
}

const products = [
  Product('حليب طازج', 'ألبان النيل', '1,200', '1 لتر', '🥛', discount: 10),
  Product('زيت دوار الشمس', 'سوبر ماركت المدينة', '2,500', '1 لتر', '🫒', discount: 15),
  Product('خبز طازج', 'مخبز المدينة', '300', 'الرغيف', '🥖', discount: 0),
  Product('طماطم', 'سوبر ماركت المدينة', '800', '1 كجم', '🍅'),
  Product('شامبو', 'جمالك', '3,500', '400 مل', '🧴'),
  Product('جبنة بيضاء', 'ألبان النيل', '2,000', '500 جم', '🧀'),
];

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final Map<int, int> cart = {};
  int tab = 0;
  int get count => cart.values.fold(0, (a, b) => a + b);

  void add(int index) => setState(() => cart[index] = (cart[index] ?? 0) + 1);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: pale,
        elevation: 0,
        title: Row(children: [
          Container(
            width: 38, height: 38,
            decoration: BoxDecoration(color: teal, borderRadius: BorderRadius.circular(12)),
            child: const Center(child: Text('B', style: TextStyle(color: Colors.white, fontSize: 25, fontWeight: FontWeight.w900))),
          ),
          const SizedBox(width: 9),
          const Text('B MARKET', style: TextStyle(color: deepTeal, fontWeight: FontWeight.w900, letterSpacing: .5)),
        ]),
        actions: [
          IconButton(onPressed: () {}, icon: const Icon(Icons.notifications_none_rounded, color: ink)),
          IconButton(onPressed: () {}, icon: const Icon(Icons.location_on_outlined, color: teal)),
        ],
      ),
      body: tab == 2 ? CartScreen(cart: cart, onAdd: add, onRemove: (i) => setState(() {
        if ((cart[i] ?? 0) <= 1) { cart.remove(i); } else { cart[i] = cart[i]! - 1; }
      })) : tab == 0 ? _home() : _placeholder(),
      bottomNavigationBar: NavigationBar(
        selectedIndex: tab,
        onDestinationSelected: (v) => setState(() => tab = v),
        backgroundColor: Colors.white,
        indicatorColor: teal.withOpacity(.12),
        destinations: [
          const NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'الرئيسية'),
          const NavigationDestination(icon: Icon(Icons.storefront_outlined), label: 'المتاجر'),
          NavigationDestination(icon: Badge(label: Text('$count'), isLabelVisible: count > 0, child: const Icon(Icons.shopping_bag_outlined)), label: 'السلة'),
          const NavigationDestination(icon: Icon(Icons.person_outline), label: 'حسابي'),
        ],
      ),
    );
  }

  Widget _home() => ListView(
    padding: const EdgeInsets.fromLTRB(16, 4, 16, 22),
    children: [
      TextField(
        decoration: InputDecoration(
          hintText: 'ابحث عن منتج أو متجر...',
          prefixIcon: const Icon(Icons.search, color: teal),
          filled: true, fillColor: Colors.white,
          contentPadding: const EdgeInsets.symmetric(vertical: 4),
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(18), borderSide: BorderSide.none),
        ),
      ),
      const SizedBox(height: 16),
      Container(
        height: 158, padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          gradient: const LinearGradient(colors: [deepTeal, teal], begin: Alignment.topRight, end: Alignment.bottomLeft),
          borderRadius: BorderRadius.circular(24),
        ),
        child: Row(children: [
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisAlignment: MainAxisAlignment.center, children: [
            const Text('كل احتياجاتك\nلحد باب بيتك', style: TextStyle(color: Colors.white, fontSize: 23, fontWeight: FontWeight.w900, height: 1.25)),
            const SizedBox(height: 12),
            FilledButton(
              style: FilledButton.styleFrom(backgroundColor: orange, foregroundColor: Colors.white),
              onPressed: () {},
              child: const Text('تسوق الآن'),
            ),
          ])),
          const Text('🛒', style: TextStyle(fontSize: 74)),
        ]),
      ),
      const SizedBox(height: 22),
      _sectionTitle('تسوق حسب القسم', 'عرض الكل'),
      const SizedBox(height: 12),
      SizedBox(height: 105, child: ListView(scrollDirection: Axis.horizontal, children: const [
        CategoryTile('🛒', 'السوبر ماركت', Color(0xFFE0F5F1)),
        CategoryTile('🥖', 'المخبز', Color(0xFFFFEEDC)),
        CategoryTile('🥛', 'الألبان', Color(0xFFE8F0FF)),
        CategoryTile('🧴', 'العناية بالبشرة', Color(0xFFFFE8EE)),
        CategoryTile('🥬', 'الخضروات', Color(0xFFEAF5DE)),
      ])),
      const SizedBox(height: 22),
      _sectionTitle('عروض مميزة', 'المزيد'),
      const SizedBox(height: 12),
      GridView.builder(
        shrinkWrap: true, physics: const NeverScrollableScrollPhysics(),
        itemCount: products.length,
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2, mainAxisSpacing: 12, crossAxisSpacing: 12, childAspectRatio: .78),
        itemBuilder: (context, i) => ProductCard(product: products[i], onAdd: () => add(i)),
      ),
    ],
  );

  Widget _sectionTitle(String title, String action) => Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
    Text(title, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w900, color: ink)),
    Text(action, style: const TextStyle(color: teal, fontWeight: FontWeight.bold)),
  ]);

  Widget _placeholder() => const Center(child: Text('القسم قيد التجهيز', style: TextStyle(fontSize: 18, color: ink)));
}

class CategoryTile extends StatelessWidget {
  final String emoji, label;
  final Color color;
  const CategoryTile(this.emoji, this.label, this.color, {super.key});
  @override
  Widget build(BuildContext context) => Container(
    width: 104, margin: const EdgeInsets.only(left: 10),
    decoration: BoxDecoration(color: color, borderRadius: BorderRadius.circular(18)),
    child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
      Text(emoji, style: const TextStyle(fontSize: 32)),
      const SizedBox(height: 7),
      Text(label, textAlign: TextAlign.center, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.bold, color: ink)),
    ]),
  );
}

class ProductCard extends StatelessWidget {
  final Product product;
  final VoidCallback onAdd;
  const ProductCard({super.key, required this.product, required this.onAdd});
  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.all(12),
    decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(20), boxShadow: [BoxShadow(color: Colors.black.withOpacity(.035), blurRadius: 12, offset: const Offset(0, 4))]),
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Expanded(child: Center(child: Text(product.emoji, style: const TextStyle(fontSize: 54)))),
      if (product.discount > 0) Text('خصم ${product.discount}%', style: const TextStyle(color: orange, fontWeight: FontWeight.bold, fontSize: 11)),
      Text(product.name, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w900, color: ink)),
      Text('${product.store} • ${product.unit}', maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 10, color: Colors.grey)),
      const SizedBox(height: 8),
      Row(children: [
        Expanded(child: Text('${product.price} ج.س', style: const TextStyle(color: deepTeal, fontWeight: FontWeight.w900))),
        InkWell(onTap: onAdd, borderRadius: BorderRadius.circular(12), child: Container(padding: const EdgeInsets.all(7), decoration: BoxDecoration(color: orange, borderRadius: BorderRadius.circular(12)), child: const Icon(Icons.add, color: Colors.white, size: 19))),
      ]),
    ]),
  );
}

class CartScreen extends StatelessWidget {
  final Map<int, int> cart;
  final void Function(int) onAdd, onRemove;
  const CartScreen({super.key, required this.cart, required this.onAdd, required this.onRemove});
  @override
  Widget build(BuildContext context) {
    final entries = cart.entries.toList();
    return ListView(padding: const EdgeInsets.all(16), children: [
      const Text('سلة مشترياتك', style: TextStyle(fontSize: 23, fontWeight: FontWeight.w900, color: ink)),
      const SizedBox(height: 14),
      if (entries.isEmpty) const Padding(padding: EdgeInsets.all(40), child: Center(child: Text('السلة لسه فاضية 🛒'))),
      ...entries.map((e) {
        final p = products[e.key];
        return Card(color: Colors.white, elevation: 0, child: ListTile(
          leading: Text(p.emoji, style: const TextStyle(fontSize: 30)),
          title: Text(p.name, style: const TextStyle(fontWeight: FontWeight.bold)),
          subtitle: Text('${p.price} ج.س • ${p.store}'),
          trailing: Row(mainAxisSize: MainAxisSize.min, children: [
            IconButton(onPressed: () => onRemove(e.key), icon: const Icon(Icons.remove_circle_outline)),
            Text('${e.value}', style: const TextStyle(fontWeight: FontWeight.bold)),
            IconButton(onPressed: () => onAdd(e.key), icon: const Icon(Icons.add_circle_outline, color: teal)),
          ]),
        ));
      }),
      if (entries.isNotEmpty) Padding(
        padding: const EdgeInsets.only(top: 18),
        child: FilledButton(
          style: FilledButton.styleFrom(backgroundColor: orange, padding: const EdgeInsets.all(16)),
          onPressed: () => ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('الخطوة التالية: إكمال العنوان والدفع'))),
          child: const Text('متابعة إتمام الطلب', style: TextStyle(fontWeight: FontWeight.bold)),
        ),
      ),
    ]);
  }
}
